# Gatherly — Social Invitation Platform

**Phase 1: Foundation.** A premium, mobile-first shell for a social invitation
platform: design system, responsive navigation, page scaffolds, and
Supabase-ready client architecture.

## Tech stack

- **Next.js 16** (App Router, Turbopack, Cache Components)
- **TypeScript** in strict mode
- **Tailwind CSS 4** with semantic, themeable design tokens
- **Supabase** client factories (`@supabase/supabase-js`) — integration-ready,
  not yet connected
- **Lucide** icons
- **Vitest + Testing Library** for automated UI tests

## Getting started

```bash
npm install
cp .env.example .env.local   # optional in Phase 1 — the app runs fine without it
npm run dev                  # http://localhost:3000
```

### Scripts

| Command             | What it does                              |
| ------------------- | ----------------------------------------- |
| `npm run dev`       | Start the dev server                      |
| `npm run build`     | Production build                          |
| `npm run start`     | Serve the production build                |
| `npm run lint`      | ESLint (next/core-web-vitals + TS rules)  |
| `npm run typecheck` | `tsc --noEmit` (strict)                   |
| `npm test`          | Vitest UI tests                           |
| `npm run test:watch`| Vitest in watch mode                      |

## What's real vs demo (Phase 1)

There is **no authentication and no backend yet**, by design.

- All people, events and invitations on screen come from
  `src/data/demo-data.ts` and every such surface carries a **"Demo data"**
  badge. Nothing is persisted anywhere.
- Supabase factories live in `src/lib/supabase/` (`client.ts`, `server.ts`).
  They are lazy, env-guarded, and report *"not configured"* until you add
  credentials from `.env.example` to `.env.local`.
- Buttons that require a backend (messaging, sign-out) are **disabled with an
  explanatory tooltip** rather than pretending to work.

## Structure

```
src/
  app/                    # Routes: / /friends /create-event /invitations /profile
    loading.tsx           # Global + per-route loading skeletons
    error.tsx             # Route error boundary with retry
    not-found.tsx         # 404 page
  components/
    ui/                   # Design system: Button, Card, Input, Dialog, Toast,
                          # Badge, Avatar, Skeleton, EmptyState, Tabs, Switch…
    layout/               # AppShell (sidebar + top bar + mobile tab bar), theme toggle
    features/             # EventCard, InvitationCard
  lib/
    navigation.ts         # Single source of truth for primary nav
    theme/                # Theme provider (light/dark/system, no-flash script)
    supabase/             # Env-guarded browser + server client factories
    utils.ts
  data/demo-data.ts       # Clearly-labelled placeholder content
  types/                  # Shared domain types (Profile, Friend, EventItem, Invitation)
  test/                   # Vitest setup + provider-aware render helper
```

## Design system

Tokens (colors, radii, motion) are CSS variables in `src/app/globals.css`,
exposed to Tailwind via `@theme inline`. Dark mode is the `.dark` class on
`<html>`, controlled from the header toggle or **Profile → Appearance**, with a
pre-hydration script to prevent theme flash. Layouts: full sidebar on desktop,
icon rail on tablet, top bar + raised-action bottom tab bar on mobile.

## Testing

27 UI tests cover the design-system primitives, navigation links, theme
switching, the create-event form validation, invitation accept/cancel flows,
friend search/empty states, dialogs and the 404 page. Run `npm test`.
