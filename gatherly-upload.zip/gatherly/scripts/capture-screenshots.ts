/**
 * One-off screenshot capture of every route (desktop light/dark + mobile).
 * Run: npx tsx scripts/capture-screenshots.ts
 */
import { chromium } from "playwright";
import { mkdirSync } from "node:fs";

const BASE = "http://localhost:8080";
const OUT = new URL("../screenshots/", import.meta.url).pathname;

const routes = [
  { path: "/", name: "home" },
  { path: "/friends", name: "friends" },
  { path: "/create-event", name: "create-event" },
  { path: "/invitations", name: "invitations" },
  { path: "/profile", name: "profile" },
];

async function main() {
  mkdirSync(OUT, { recursive: true });
  const browser = await chromium.launch();

  const themes = [
    { key: "light", storage: "light" },
    { key: "dark", storage: "dark" },
  ] as const;

  // Desktop: every route, both themes
  for (const theme of themes) {
    const ctx = await browser.newContext({
      viewport: { width: 1280, height: 860 },
      deviceScaleFactor: 2,
    });
    await ctx.addInitScript(
      (value) => window.localStorage.setItem("gatherly-theme", value),
      theme.storage,
    );
    const page = await ctx.newPage();
    for (const route of routes) {
      await page.goto(`${BASE}${route.path}`, { waitUntil: "networkidle" });
      await page.waitForTimeout(300);
      await page.screenshot({
        path: `${OUT}desktop-${theme.key}-${route.name}.png`,
        fullPage: false,
      });
      console.log(`captured desktop-${theme.key}-${route.name}`);
    }
    await ctx.close();
  }

  // Mobile: home + invitations, both themes
  for (const theme of themes) {
    const ctx = await browser.newContext({
      viewport: { width: 390, height: 844 },
      deviceScaleFactor: 3,
      isMobile: true,
      hasTouch: true,
    });
    await ctx.addInitScript(
      (value) => window.localStorage.setItem("gatherly-theme", value),
      theme.storage,
    );
    const page = await ctx.newPage();
    for (const route of [routes[0], routes[3]]) {
      await page.goto(`${BASE}${route.path}`, { waitUntil: "networkidle" });
      await page.waitForTimeout(300);
      await page.screenshot({
        path: `${OUT}mobile-${theme.key}-${route.name}.png`,
        fullPage: false,
      });
      console.log(`captured mobile-${theme.key}-${route.name}`);
      // Also verify no horizontal overflow
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth - window.innerWidth,
      );
      console.log(`  horizontal overflow: ${overflow}px`);
    }
    await ctx.close();
  }

  await browser.close();
  console.log("done");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
