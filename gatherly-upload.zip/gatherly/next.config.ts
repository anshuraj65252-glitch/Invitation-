import type { NextConfig } from "next";

/**
 * NEXT_BASE_PATH is set by the GitHub Pages workflow so assets resolve when
 * the site is served from https://<user>.github.io/<repo>/. Locally it stays
 * unset, so the app runs from the domain root.
 */
const basePath = process.env.NEXT_BASE_PATH || undefined;

const nextConfig: NextConfig = {
  // Static export so the app can be served by any static host / preview proxy.
  output: "export",
  trailingSlash: true,
  basePath,
  assetPrefix: basePath,
  // Allow the hosted preview proxy to load dev assets (HMR, RSC payloads).
  allowedDevOrigins: ["*.e2b.app", "*.e2b.dev"],
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;
