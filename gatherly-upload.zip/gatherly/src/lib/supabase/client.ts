import { createClient, type SupabaseClient } from "@supabase/supabase-js";

/**
 * Browser-side Supabase client (lazy singleton).
 *
 * The client is created on first use so that builds and tests never require
 * credentials. When the environment variables are absent, `isSupabaseConfigured`
 * is `false` and callers should render friendly fallback UI rather than throw.
 *
 * Wiring (see .env.example):
 *   NEXT_PUBLIC_SUPABASE_URL      Project URL  (safe to expose to the browser)
 *   NEXT_PUBLIC_SUPABASE_ANON_KEY Public anon key (RLS must protect data)
 */

let browserClient: SupabaseClient | null = null;

export function isSupabaseConfigured(): boolean {
  return Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL &&
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  );
}

export function getSupabaseBrowserClient(): SupabaseClient {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    throw new Error(
      "Supabase is not configured. Copy .env.example to .env.local and set " +
        "NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.",
    );
  }

  if (!browserClient) {
    browserClient = createClient(url, anonKey);
  }
  return browserClient;
}
