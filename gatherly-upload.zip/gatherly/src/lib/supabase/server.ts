import { createClient, type SupabaseClient } from "@supabase/supabase-js";

/**
 * Server-side Supabase client factory (Route Handlers / Server Components).
 *
 * Authentication will be wired in a later phase (cookie-backed sessions via
 * @supabase/ssr). For now this factory simply creates a client bound to the
 * public anon key so read paths can be integrated without committing to an
 * auth strategy.
 *
 * NEVER expose a service-role key through this module's public env vars.
 */
export function createSupabaseServerClient(): SupabaseClient {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    throw new Error(
      "Supabase is not configured. Copy .env.example to .env.local and set " +
        "NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.",
    );
  }

  return createClient(url, anonKey, {
    auth: {
      // No session handling yet — auth arrives with the invitation backend.
      persistSession: false,
    },
  });
}
