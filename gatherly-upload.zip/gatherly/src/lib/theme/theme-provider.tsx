"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  useSyncExternalStore,
} from "react";

export type ThemePreference = "light" | "dark" | "system";
export type ResolvedTheme = "light" | "dark";

const STORAGE_KEY = "gatherly-theme";

interface ThemeContextValue {
  /** What the user picked */
  preference: ThemePreference;
  /** The effective theme after resolving `system` */
  resolvedTheme: ResolvedTheme;
  /** True after the client has hydrated (avoids SSR/client mismatches) */
  mounted: boolean;
  setPreference: (preference: ThemePreference) => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

/**
 * Blocking script injected before hydration so the correct theme class is
 * applied on first paint (prevents a flash of the wrong theme).
 */
export function ThemeScript() {
  const code = `(function(){try{var p=localStorage.getItem("${STORAGE_KEY}")||"system";var m=window.matchMedia("(prefers-color-scheme: dark)");var t=p==="system"?(m.matches?"dark":"light"):p;document.documentElement.classList.toggle("dark",t==="dark");}catch(e){}})();`;
  return <script dangerouslySetInnerHTML={{ __html: code }} />;
}

function readStoredPreference(): ThemePreference {
  if (typeof window === "undefined") return "system";
  const stored = window.localStorage.getItem(STORAGE_KEY);
  return stored === "light" || stored === "dark" || stored === "system"
    ? stored
    : "system";
}

const noSubscribe = () => () => {};

/** Hydration-safe "are we on the client" flag (no setState-in-effect). */
export function useMounted(): boolean {
  return useSyncExternalStore(
    noSubscribe,
    () => true,
    () => false,
  );
}

/** Live snapshot of the OS dark-mode preference. */
function useSystemDark(): boolean {
  return useSyncExternalStore(
    (onStoreChange) => {
      const media = window.matchMedia("(prefers-color-scheme: dark)");
      media.addEventListener("change", onStoreChange);
      return () => media.removeEventListener("change", onStoreChange);
    },
    () => window.matchMedia("(prefers-color-scheme: dark)").matches,
    () => false,
  );
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const mounted = useMounted();
  const systemDark = useSystemDark();
  const [preference, setPreferenceState] = useState<ThemePreference>(() =>
    readStoredPreference(),
  );

  const resolvedTheme: ResolvedTheme =
    preference === "system" ? (systemDark ? "dark" : "light") : preference;

  const setPreference = useCallback((next: ThemePreference) => {
    setPreferenceState(next);
    window.localStorage.setItem(STORAGE_KEY, next);
    const applied =
      next === "system"
        ? window.matchMedia("(prefers-color-scheme: dark)").matches
          ? "dark"
          : "light"
        : next;
    document.documentElement.classList.toggle("dark", applied === "dark");
  }, []);

  const value = useMemo(
    () => ({ preference, resolvedTheme, mounted, setPreference }),
    [preference, resolvedTheme, mounted, setPreference],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error("useTheme must be used inside <ThemeProvider>");
  }
  return ctx;
}
