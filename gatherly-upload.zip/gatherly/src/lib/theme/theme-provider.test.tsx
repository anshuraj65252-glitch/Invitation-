import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { renderWithProviders } from "@/test/test-utils";
import { ThemeToggle } from "@/components/layout/theme-toggle";

describe("ThemeToggle", () => {
  it("switches from system to light on first click and applies the class", async () => {
    renderWithProviders(<ThemeToggle />);
    await userEvent.click(screen.getByTestId("theme-toggle"));

    expect(document.documentElement.classList.contains("dark")).toBe(false);
    expect(window.localStorage.getItem("gatherly-theme")).toBe("light");
  });

  it("applies the dark class and persists the choice", async () => {
    renderWithProviders(<ThemeToggle />);
    const toggle = screen.getByTestId("theme-toggle");

    await userEvent.click(toggle); // system -> light
    await userEvent.click(toggle); // light -> dark

    expect(document.documentElement.classList.contains("dark")).toBe(true);
    expect(window.localStorage.getItem("gatherly-theme")).toBe("dark");
  });

  it("cycles back to system", async () => {
    renderWithProviders(<ThemeToggle />);
    const toggle = screen.getByTestId("theme-toggle");

    await userEvent.click(toggle);
    await userEvent.click(toggle);
    await userEvent.click(toggle);

    expect(window.localStorage.getItem("gatherly-theme")).toBe("system");
  });
});
