import {
  CalendarPlus,
  CircleUserRound,
  Home,
  Mail,
  Users,
} from "lucide-react";
import type { NavItem } from "@/types";

/**
 * Primary app navigation. Order matters — it is the order shown in the
 * sidebar and the mobile tab bar (Create Event sits centre-stage).
 */
export const NAV_ITEMS: NavItem[] = [
  { href: "/", label: "Home", icon: Home },
  { href: "/friends", label: "Friends", icon: Users },
  { href: "/create-event", label: "Create Event", icon: CalendarPlus },
  { href: "/invitations", label: "Invitations", icon: Mail },
  { href: "/profile", label: "Profile", icon: CircleUserRound },
];

export function isNavItemActive(pathname: string, href: string): boolean {
  if (href === "/") return pathname === "/";
  return pathname === href || pathname.startsWith(`${href}/`);
}
