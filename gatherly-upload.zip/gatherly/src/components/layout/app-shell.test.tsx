import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { NAV_ITEMS } from "@/lib/navigation";
import { renderWithProviders } from "@/test/test-utils";
import { AppShell } from "./app-shell";

vi.mock("next/navigation", () => ({
  usePathname: () => "/friends",
}));

describe("AppShell", () => {
  it("exposes every primary navigation destination as a link", () => {
    renderWithProviders(<AppShell>content</AppShell>);

    // Sidebar + mobile tab bar both render the nav — assert at least one of each
    for (const item of NAV_ITEMS) {
      const links = screen
        .getAllByRole("link")
        .filter((link) => link.getAttribute("href") === item.href);
      expect(links.length, `missing nav link for ${item.label}`).toBeGreaterThan(0);
    }
  });

  it("marks the active destination with aria-current", () => {
    renderWithProviders(<AppShell>content</AppShell>);
    const activeLinks = screen
      .getAllByRole("link")
      .filter((link) => link.getAttribute("aria-current") === "page");
    expect(activeLinks.length).toBeGreaterThan(0);
    for (const link of activeLinks) {
      expect(link.getAttribute("href")).toBe("/friends");
    }
  });

  it("renders the page content", () => {
    renderWithProviders(
      <AppShell>
        <p>Page body</p>
      </AppShell>,
    );
    expect(screen.getByText("Page body")).toBeInTheDocument();
  });

  it("opens a notifications dialog from the bell button", async () => {
    renderWithProviders(<AppShell>content</AppShell>);
    await userEvent.click(
      screen.getByRole("button", { name: /open notifications/i }),
    );
    expect(
      await screen.findByRole("dialog", { name: /notifications/i }),
    ).toBeInTheDocument();
    expect(screen.getByText(/all caught up/i)).toBeInTheDocument();
  });
});
