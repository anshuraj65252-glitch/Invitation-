"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Bell, Sparkles } from "lucide-react";
import { isNavItemActive, NAV_ITEMS } from "@/lib/navigation";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Dialog } from "@/components/ui/dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { demoProfile } from "@/data/demo-data";

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link
      href="/"
      className="flex items-center gap-2.5 rounded-lg focus-visible:outline-ring"
      aria-label="Gatherly home"
    >
      <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
        <Sparkles className="h-5 w-5" />
      </span>
      {!compact && (
        <span className="text-lg font-semibold tracking-tight">Gatherly</span>
      )}
    </Link>
  );
}

function NavLink({
  href,
  label,
  icon: Icon,
  active,
  compact = false,
}: {
  href: string;
  label: string;
  icon: NavIcon;
  active: boolean;
  compact?: boolean;
}) {
  return (
    <Link
      href={href}
      aria-current={active ? "page" : undefined}
      title={compact ? label : undefined}
      className={cn(
        "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
        compact && "justify-center px-0",
        active
          ? "bg-accent text-accent-foreground"
          : "text-muted-foreground hover:bg-muted hover:text-foreground",
      )}
    >
      <Icon className="h-5 w-5 shrink-0" />
      {!compact && label}
    </Link>
  );
}

type NavIcon = React.ComponentType<{ className?: string }>;

function NotificationsDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog
      open={open}
      onOpenChange={onOpenChange}
      title="Notifications"
      description="RSVP updates, new invitations and friend activity will show up here."
    >
      <EmptyState
        icon={Bell}
        title="You're all caught up"
        description="Nothing new right now — we'll keep you posted once the backend is connected."
        className="border-0 py-8"
      />
    </Dialog>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  return (
    <div className="flex min-h-dvh">
      {/* Desktop / tablet sidebar: icon rail at md, full labels at lg+ */}
      <aside
        className="fixed inset-y-0 left-0 z-40 hidden w-20 flex-col border-r border-border bg-card/80 backdrop-blur md:flex lg:w-64"
        aria-label="Primary"
      >
        <div className="flex h-16 items-center justify-center border-b border-border px-3 lg:justify-start lg:px-5">
          <Brand compact />
          <span className="ml-2.5 hidden text-lg font-semibold tracking-tight lg:inline">
            Gatherly
          </span>
        </div>

        <nav className="flex flex-1 flex-col gap-1 p-3" aria-label="Main navigation">
          {NAV_ITEMS.map((item) => (
            <div key={item.href}>
              <div className="lg:hidden">
                <NavLink
                  {...item}
                  compact
                  active={isNavItemActive(pathname, item.href)}
                />
              </div>
              <div className="hidden lg:block">
                <NavLink {...item} active={isNavItemActive(pathname, item.href)} />
              </div>
            </div>
          ))}
        </nav>

        <div className="border-t border-border p-3">
          <div className="flex items-center justify-center gap-2 lg:justify-between lg:px-2">
            <ThemeToggle />
            <Link
              href="/profile"
              className="hidden items-center gap-2 rounded-lg p-1 transition-colors hover:bg-muted lg:flex"
              aria-label="Open your profile"
            >
              <Avatar name={demoProfile.name} size="sm" />
              <span className="max-w-24 truncate text-sm font-medium">
                {demoProfile.name}
              </span>
              <Badge variant="outline" className="text-[10px]">
                Demo
              </Badge>
            </Link>
          </div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col md:pl-20 lg:pl-64">
        {/* Top bar (all breakpoints) */}
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-2 border-b border-border bg-background/80 px-4 backdrop-blur sm:px-6">
          <div className="md:hidden">
            <Brand />
          </div>
          <div className="hidden md:block">
            <p className="text-sm text-muted-foreground">
              Welcome back,{" "}
              <span className="font-medium text-foreground">
                {demoProfile.name.split(" ")[0]}
              </span>
            </p>
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              aria-label="Open notifications"
              onClick={() => setNotificationsOpen(true)}
              className="inline-flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              <Bell className="h-5 w-5" />
            </button>
            <ThemeToggle className="md:hidden" />
            <Link
              href="/profile"
              aria-label="Open your profile"
              className="rounded-full transition-opacity hover:opacity-80 md:hidden"
            >
              <Avatar name={demoProfile.name} size="sm" />
            </Link>
          </div>
        </header>

        <main className="mx-auto w-full max-w-5xl flex-1 px-4 pb-28 pt-6 sm:px-6 md:pb-10 lg:pt-8">
          {children}
        </main>
      </div>

      {/* Mobile bottom tab bar */}
      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/90 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden"
        aria-label="Main navigation"
      >
        <div className="grid grid-cols-5">
          {NAV_ITEMS.map((item, index) => {
            const active = isNavItemActive(pathname, item.href);
            const Icon = item.icon;
            const isCreate = item.href === "/create-event";
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className="flex flex-col items-center gap-1 py-2"
              >
                {isCreate ? (
                  <span
                    className={cn(
                      "-mt-5 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg ring-4 ring-background transition-transform active:scale-95",
                      index === 2 && active && "opacity-90",
                    )}
                  >
                    <Icon className="h-6 w-6" />
                  </span>
                ) : (
                  <Icon
                    className={cn(
                      "h-6 w-6",
                      active ? "text-primary" : "text-muted-foreground",
                    )}
                  />
                )}
                <span
                  className={cn(
                    "text-[10px] font-medium",
                    isCreate
                      ? "text-muted-foreground"
                      : active
                        ? "text-primary"
                        : "text-muted-foreground",
                  )}
                >
                  {item.label === "Create Event" ? "Create" : item.label}
                </span>
              </Link>
            );
          })}
        </div>
      </nav>

      <NotificationsDialog
        open={notificationsOpen}
        onOpenChange={setNotificationsOpen}
      />
    </div>
  );
}
