"use client";

import { Monitor, Moon, Sun } from "lucide-react";
import { useTheme, type ThemePreference } from "@/lib/theme/theme-provider";
import { cn } from "@/lib/utils";

/** Single-button toggle that cycles light -> dark -> system. */
export function ThemeToggle({ className }: { className?: string }) {
  const { preference, resolvedTheme, mounted, setPreference } = useTheme();

  const next: Record<ThemePreference, ThemePreference> = {
    light: "dark",
    dark: "system",
    system: "light",
  };

  if (!mounted) {
    // Stable placeholder so SSR and first client render agree.
    return (
      <span
        className={cn("inline-flex h-10 w-10 items-center justify-center", className)}
        aria-hidden
      >
        <Sun className="h-5 w-5 text-muted-foreground" />
      </span>
    );
  }

  const LabelIcon =
    preference === "system" ? Monitor : resolvedTheme === "dark" ? Moon : Sun;

  return (
    <button
      type="button"
      onClick={() => setPreference(next[preference])}
      aria-label={`Theme: ${preference}. Activate to switch to ${next[preference]}.`}
      title={`Theme: ${preference} (click for ${next[preference]})`}
      data-testid="theme-toggle"
      className={cn(
        "inline-flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground",
        "transition-colors hover:bg-muted hover:text-foreground",
        className,
      )}
    >
      <LabelIcon className="h-5 w-5" />
    </button>
  );
}

/** Full theme picker used on the Profile page. */
export function ThemePreferencePicker() {
  const { preference, setPreference } = useTheme();
  const options: { value: ThemePreference; label: string; icon: typeof Sun }[] = [
    { value: "light", label: "Light", icon: Sun },
    { value: "dark", label: "Dark", icon: Moon },
    { value: "system", label: "System", icon: Monitor },
  ];

  return (
    <div role="radiogroup" aria-label="Color theme" className="flex gap-2">
      {options.map(({ value, label, icon: Icon }) => {
        const active = preference === value;
        return (
          <button
            key={value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => setPreference(value)}
            className={cn(
              "flex flex-1 items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-sm font-medium transition-colors",
              active
                ? "border-primary bg-accent text-accent-foreground"
                : "border-border text-muted-foreground hover:bg-muted hover:text-foreground",
            )}
          >
            <Icon className="h-4 w-4" />
            {label}
          </button>
        );
      })}
    </div>
  );
}
