import { cn } from "@/lib/utils";

/** Animated placeholder block used by route-level loading states. */
export function Skeleton({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      aria-hidden
      className={cn("animate-pulse rounded-md bg-muted", className)}
      {...props}
    />
  );
}

/** Skeleton mimicking a list card (avatar + two text lines). */
export function CardSkeleton({ lines = 2 }: { lines?: number }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center gap-3">
        <Skeleton className="h-10 w-10 rounded-full" />
        <div className="flex-1 space-y-2">
          {Array.from({ length: lines }, (_, i) => `line-${i}`).map((key, i) => (
            <Skeleton
              key={key}
              className={cn("h-3", i === 0 ? "w-1/2" : "w-3/4")}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
