import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Dialog } from "./dialog";
import { EmptyState } from "./empty-state";
import { Skeleton } from "./skeleton";

describe("EmptyState", () => {
  it("renders title, description and action", () => {
    render(
      <EmptyState
        title="No invitations yet"
        description="They'll land here."
        action={<button type="button">Explore</button>}
      />,
    );
    expect(screen.getByText("No invitations yet")).toBeInTheDocument();
    expect(screen.getByText("They'll land here.")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Explore" })).toBeInTheDocument();
  });
});

describe("Dialog", () => {
  it("renders nothing while closed", () => {
    render(
      <Dialog open={false} onOpenChange={() => {}} title="Hidden" />,
    );
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("renders content when open and closes via the close button", async () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Hello" description="Desc">
        <p>Dialog body</p>
      </Dialog>,
    );
    expect(screen.getByRole("dialog", { name: "Hello" })).toBeInTheDocument();
    expect(screen.getByText("Dialog body")).toBeInTheDocument();

    await userEvent.click(screen.getByRole("button", { name: /close dialog/i }));
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("closes on Escape", async () => {
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Escapable" />);
    await userEvent.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

describe("Skeleton", () => {
  it("renders a non-semantic placeholder", () => {
    const { container } = render(<Skeleton className="h-4 w-4" />);
    expect(container.firstChild).toHaveClass("animate-pulse");
  });
});
