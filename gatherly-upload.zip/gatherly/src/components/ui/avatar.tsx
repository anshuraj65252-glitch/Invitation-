import { cn, initialsOf } from "@/lib/utils";

const AVATAR_PALETTES = [
  "bg-violet-500/15 text-violet-600 dark:text-violet-300",
  "bg-sky-500/15 text-sky-600 dark:text-sky-300",
  "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300",
  "bg-amber-500/15 text-amber-600 dark:text-amber-300",
  "bg-rose-500/15 text-rose-600 dark:text-rose-300",
  "bg-indigo-500/15 text-indigo-600 dark:text-indigo-300",
];

function paletteFor(name: string): string {
  let hash = 0;
  for (const ch of name) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  return AVATAR_PALETTES[hash % AVATAR_PALETTES.length];
}

const sizeClasses = {
  sm: "h-8 w-8 text-xs",
  md: "h-10 w-10 text-sm",
  lg: "h-14 w-14 text-lg",
} as const;

export interface AvatarProps {
  name: string;
  size?: keyof typeof sizeClasses;
  className?: string;
}

/** Initials-based avatar with a deterministic pastel palette. */
export function Avatar({ name, size = "md", className }: AvatarProps) {
  return (
    <span
      aria-hidden
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-full font-semibold",
        sizeClasses[size],
        paletteFor(name),
        className,
      )}
    >
      {initialsOf(name)}
    </span>
  );
}

/** Overlapping avatar stack used for attendee previews. */
export function AvatarStack({
  names,
  max = 4,
  size = "sm",
  className,
}: {
  names: string[];
  max?: number;
  size?: keyof typeof sizeClasses;
  className?: string;
}) {
  const visible = names.slice(0, max);
  const overflow = names.length - visible.length;
  return (
    <span className={cn("inline-flex -space-x-2", className)} aria-hidden>
      {visible.map((name) => (
        <Avatar
          key={name}
          name={name}
          size={size}
          className="ring-2 ring-card"
        />
      ))}
      {overflow > 0 ? (
        <span
          className={cn(
            "inline-flex items-center justify-center rounded-full bg-muted font-medium text-muted-foreground ring-2 ring-card",
            sizeClasses[size],
          )}
        >
          +{overflow}
        </span>
      ) : null}
    </span>
  );
}
