import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Button } from "./button";

describe("Button", () => {
  it("renders its label", () => {
    render(<Button>Save changes</Button>);
    expect(
      screen.getByRole("button", { name: /save changes/i }),
    ).toBeInTheDocument();
  });

  it("fires onClick when enabled", async () => {
    const onClick = vi.fn();
    render(<Button onClick={onClick}>Do it</Button>);
    await userEvent.click(screen.getByRole("button", { name: /do it/i }));
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("does not fire onClick when disabled", async () => {
    const onClick = vi.fn();
    render(
      <Button disabled onClick={onClick}>
        Disabled
      </Button>,
    );
    const button = screen.getByRole("button", { name: /disabled/i });
    expect(button).toBeDisabled();
    await userEvent.click(button);
    expect(onClick).not.toHaveBeenCalled();
  });

  it("is non-interactive while loading", () => {
    render(<Button loading>Saving</Button>);
    expect(screen.getByRole("button", { name: /saving/i })).toBeDisabled();
  });

  it("defaults to type=button to avoid accidental form submits", () => {
    render(<Button>Plain</Button>);
    expect(screen.getByRole("button", { name: /plain/i })).toHaveAttribute(
      "type",
      "button",
    );
  });
});
