import { forwardRef, type InputHTMLAttributes, type TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const baseFieldClasses =
  "w-full rounded-lg border border-input bg-transparent px-3 text-sm text-foreground " +
  "placeholder:text-muted-foreground/70 transition-colors duration-150 " +
  "hover:border-foreground/20 focus:border-ring focus:outline-none focus:ring-2 focus:ring-ring/25 " +
  "disabled:cursor-not-allowed disabled:opacity-50";

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  invalid?: boolean;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  function Input({ className, invalid, ...props }, ref) {
    return (
      <input
        ref={ref}
        aria-invalid={invalid || undefined}
        className={cn(
          baseFieldClasses,
          "h-10",
          invalid && "border-destructive focus:border-destructive focus:ring-destructive/25",
          className,
        )}
        {...props}
      />
    );
  },
);

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  invalid?: boolean;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  function Textarea({ className, invalid, ...props }, ref) {
    return (
      <textarea
        ref={ref}
        aria-invalid={invalid || undefined}
        className={cn(
          baseFieldClasses,
          "min-h-24 py-2",
          invalid && "border-destructive focus:border-destructive focus:ring-destructive/25",
          className,
        )}
        {...props}
      />
    );
  },
);
