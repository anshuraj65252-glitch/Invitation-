"use client";

import { Calendar, Check, Clock, MapPin, X } from "lucide-react";
import type { Invitation } from "@/types";
import { formatEventDate } from "@/lib/utils";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export interface InvitationCardProps {
  invitation: Invitation;
  onAccept?: (id: string) => void;
  onDecline?: (id: string) => void;
  onCancel?: (id: string) => void;
}

const statusBadge: Record<Invitation["status"], React.ReactNode> = {
  pending: <Badge variant="warning">Pending</Badge>,
  accepted: <Badge variant="success">Accepted</Badge>,
  declined: <Badge variant="destructive">Declined</Badge>,
};

export function InvitationCard({
  invitation,
  onAccept,
  onDecline,
  onCancel,
}: InvitationCardProps) {
  const isReceived = invitation.direction === "received";
  const isPending = invitation.status === "pending";

  return (
    <Card className="flex flex-col gap-4 p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <Avatar name={invitation.otherPartyName} />
          <div className="min-w-0">
            <h3 className="truncate text-base font-semibold">
              {invitation.eventTitle}
            </h3>
            <p className="text-sm text-muted-foreground">
              {isReceived
                ? `Invited by ${invitation.otherPartyName}`
                : `Sent to ${invitation.otherPartyName}`}
            </p>
          </div>
        </div>
        <span className="shrink-0">{statusBadge[invitation.status]}</span>
      </div>

      <dl className="grid gap-1.5 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4" aria-hidden />
          <dd>{formatEventDate(invitation.date)}</dd>
          <Clock className="ml-2 h-4 w-4" aria-hidden />
          <dd>{invitation.time}</dd>
        </div>
        <div className="flex items-center gap-2">
          <MapPin className="h-4 w-4" aria-hidden />
          <dd className="truncate">{invitation.location}</dd>
        </div>
      </dl>

      {isPending ? (
        <div className="flex gap-2 pt-1">
          {isReceived ? (
            <>
              <Button
                size="sm"
                className="flex-1"
                onClick={() => onAccept?.(invitation.id)}
              >
                <Check className="h-4 w-4" />
                Accept
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="flex-1"
                onClick={() => onDecline?.(invitation.id)}
              >
                <X className="h-4 w-4" />
                Decline
              </Button>
            </>
          ) : (
            <Button
              size="sm"
              variant="outline"
              onClick={() => onCancel?.(invitation.id)}
            >
              Cancel invitation
            </Button>
          )}
        </div>
      ) : null}
    </Card>
  );
}
