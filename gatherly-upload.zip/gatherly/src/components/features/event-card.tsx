"use client";

import { useState } from "react";
import { Calendar, Clock, Globe, Lock, MapPin, Users } from "lucide-react";
import type { EventItem } from "@/types";
import { formatEventDate } from "@/lib/utils";
import { AvatarStack } from "@/components/ui/avatar";
import { Badge, type BadgeVariant } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";

const privacyMeta: Record<
  EventItem["privacy"],
  { label: string; icon: React.ComponentType<{ className?: string }>; variant: BadgeVariant }
> = {
  public: { label: "Public", icon: Globe, variant: "success" },
  friends: { label: "Friends only", icon: Users, variant: "accent" },
  private: { label: "Private", icon: Lock, variant: "warning" },
};

export function EventCard({ event }: { event: EventItem }) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  const privacy = privacyMeta[event.privacy];
  const PrivacyIcon = privacy.icon;

  return (
    <Card className="flex flex-col gap-4 p-5 transition-shadow hover:shadow-md">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-base font-semibold">{event.title}</h3>
          <p className="mt-0.5 text-sm text-muted-foreground">
            Hosted by {event.hostName}
          </p>
        </div>
        <Badge variant={privacy.variant} className="shrink-0">
          <PrivacyIcon className="h-3 w-3" />
          {privacy.label}
        </Badge>
      </div>

      <dl className="grid gap-1.5 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4" aria-hidden />
          <dt className="sr-only">Date</dt>
          <dd>{formatEventDate(event.date)}</dd>
          <Clock className="ml-2 h-4 w-4" aria-hidden />
          <dt className="sr-only">Time</dt>
          <dd>{event.time}</dd>
        </div>
        <div className="flex items-center gap-2">
          <MapPin className="h-4 w-4" aria-hidden />
          <dt className="sr-only">Location</dt>
          <dd className="truncate">{event.location}</dd>
        </div>
      </dl>

      <div className="flex items-center justify-between gap-3 pt-1">
        <div className="flex items-center gap-2">
          <AvatarStack names={event.attendees} />
          <span className="text-xs text-muted-foreground">
            {event.attendeeCount} going
          </span>
        </div>
        <Button variant="outline" size="sm" onClick={() => setDetailsOpen(true)}>
          Details
        </Button>
      </div>

      <Dialog
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        title={event.title}
        description={`Hosted by ${event.hostName}`}
        footer={
          <Button onClick={() => setDetailsOpen(false)}>Close</Button>
        }
      >
        <dl className="space-y-3 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="h-4 w-4" aria-hidden />
            <dd>{formatEventDate(event.date)}</dd>
            <Clock className="ml-2 h-4 w-4" aria-hidden />
            <dd>{event.time}</dd>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-4 w-4" aria-hidden />
            <dd>{event.location}</dd>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="h-4 w-4" aria-hidden />
            <dd>
              {event.attendeeCount} attending · {event.attendees.join(", ")}
            </dd>
          </div>
        </dl>
        <p className="mt-4 rounded-lg bg-muted p-3 text-xs text-muted-foreground">
          Demo event — RSVP actions will be enabled once invitations are backed
          by Supabase.
        </p>
      </Dialog>
    </Card>
  );
}
