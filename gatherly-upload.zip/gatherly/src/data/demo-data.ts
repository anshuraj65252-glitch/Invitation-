import type { EventItem, Friend, Invitation, Profile } from "@/types";

/**
 * ⚠️ DEMO DATA — UI scaffolding only.
 *
 * These constants exist so page shells can be developed and reviewed before a
 * backend exists. They are NOT fetched from Supabase and are never written
 * anywhere. Every surface that renders them is tagged with a "Demo data"
 * badge. They will be replaced by real queries once Supabase is wired up.
 */

export const demoProfile: Profile = {
  id: "demo-user",
  name: "Sana Kapoor",
  handle: "@sana",
  bio: "Hosting things I care about, with people I like.",
  location: "Patna, IN",
};

export const demoFriends: Friend[] = [
  { id: "f1", name: "Ava Johnson", handle: "@avaj", mutualFriends: 12, status: "friend" },
  { id: "f2", name: "Rohan Mehta", handle: "@rohanm", mutualFriends: 8, status: "friend" },
  { id: "f3", name: "Mia Chen", handle: "@miachen", mutualFriends: 5, status: "friend" },
  { id: "f4", name: "Daniel Okafor", handle: "@danoka", mutualFriends: 3, status: "friend" },
  { id: "f5", name: "Priya Sharma", handle: "@priyas", mutualFriends: 15, status: "friend" },
  { id: "f6", name: "Lucas Silva", handle: "@lucass", mutualFriends: 2, status: "friend" },
  { id: "f7", name: "Emma Nakamura", handle: "@emman", mutualFriends: 6, status: "incoming" },
  { id: "f8", name: "Omar Haddad", handle: "@omarh", mutualFriends: 4, status: "outgoing" },
];

export const demoEvents: EventItem[] = [
  {
    id: "e1",
    title: "Rooftop Potluck Dinner",
    date: "2026-10-24",
    time: "19:00",
    location: "Skyline Terrace, Boring Road",
    hostName: "Sana Kapoor",
    privacy: "friends",
    attendeeCount: 9,
    attendees: ["Ava Johnson", "Rohan Mehta", "Mia Chen", "Priya Sharma", "Lucas Silva"],
  },
  {
    id: "e2",
    title: "Sunday Morning Run Club",
    date: "2026-10-25",
    time: "06:30",
    location: "Gandhi Maidan Gate 2",
    hostName: "Mia Chen",
    privacy: "public",
    attendeeCount: 14,
    attendees: ["Mia Chen", "Daniel Okafor", "Emma Nakamura"],
  },
  {
    id: "e3",
    title: "Board Game Night",
    date: "2026-10-30",
    time: "20:00",
    location: "Ava's place",
    hostName: "Ava Johnson",
    privacy: "friends",
    attendeeCount: 6,
    attendees: ["Ava Johnson", "Priya Sharma", "Rohan Mehta", "Omar Haddad"],
  },
  {
    id: "e4",
    title: "Diwali House Party",
    date: "2026-11-08",
    time: "18:00",
    location: "Sana's home, Kankarbagh",
    hostName: "Sana Kapoor",
    privacy: "private",
    attendeeCount: 22,
    attendees: ["Rohan Mehta", "Priya Sharma", "Emma Nakamura", "Lucas Silva", "Daniel Okafor"],
  },
];

export const demoInvitations: Invitation[] = [
  {
    id: "i1",
    eventTitle: "Board Game Night",
    date: "2026-10-30",
    time: "20:00",
    location: "Ava's place",
    otherPartyName: "Ava Johnson",
    direction: "received",
    status: "pending",
  },
  {
    id: "i2",
    eventTitle: "Charity 5K Walk",
    date: "2026-11-02",
    time: "07:00",
    location: "Eco Park entrance",
    otherPartyName: "Daniel Okafor",
    direction: "received",
    status: "pending",
  },
  {
    id: "i3",
    eventTitle: "Sunday Morning Run Club",
    date: "2026-10-25",
    time: "06:30",
    location: "Gandhi Maidan Gate 2",
    otherPartyName: "Mia Chen",
    direction: "received",
    status: "accepted",
  },
  {
    id: "i4",
    eventTitle: "Rooftop Potluck Dinner",
    date: "2026-10-24",
    time: "19:00",
    location: "Skyline Terrace, Boring Road",
    otherPartyName: "Priya Sharma",
    direction: "sent",
    status: "pending",
  },
  {
    id: "i5",
    eventTitle: "Diwali House Party",
    date: "2026-11-08",
    time: "18:00",
    location: "Sana's home, Kankarbagh",
    otherPartyName: "Omar Haddad",
    direction: "sent",
    status: "pending",
  },
];
