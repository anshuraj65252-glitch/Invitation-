import { render, type RenderOptions } from "@testing-library/react";
import { ToastProvider } from "@/components/ui/toast";
import { ThemeProvider } from "@/lib/theme/theme-provider";

/** Render with the same providers the app root layout supplies. */
export function renderWithProviders(
  ui: React.ReactElement,
  options?: RenderOptions,
) {
  return render(
    <ThemeProvider>
      <ToastProvider>{ui}</ToastProvider>
    </ThemeProvider>,
    options,
  );
}

export { default as userEvent } from "@testing-library/user-event";
