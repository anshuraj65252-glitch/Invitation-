/**
 * Shared domain types for the Gatherly platform.
 * These mirror the shape the Supabase schema will expose in a later phase.
 */

export interface Profile {
  id: string;
  name: string;
  handle: string;
  bio: string;
  location: string;
}

export interface Friend {
  id: string;
  name: string;
  handle: string;
  mutualFriends: number;
  status: "friend" | "incoming" | "outgoing";
}

export type EventPrivacy = "public" | "friends" | "private";

export interface EventItem {
  id: string;
  title: string;
  /** ISO date string, yyyy-mm-dd */
  date: string;
  /** 24h "HH:MM" local time */
  time: string;
  location: string;
  hostName: string;
  privacy: EventPrivacy;
  attendeeCount: number;
  /** Attendee display names used for avatar stacks */
  attendees: string[];
}

export type InvitationStatus = "pending" | "accepted" | "declined";

export interface Invitation {
  id: string;
  eventTitle: string;
  date: string;
  time: string;
  location: string;
  otherPartyName: string;
  direction: "received" | "sent";
  status: InvitationStatus;
}

export interface NavItem {
  href: string;
  label: string;
  /** lucide-react icon component */
  icon: React.ComponentType<{ className?: string }>;
}
