"use client";

import { useMemo, useState } from "react";
import { MailOpen, Send } from "lucide-react";
import type { Invitation } from "@/types";
import { InvitationCard } from "@/components/features/invitation-card";
import { DemoDataBadge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/empty-state";
import { SegmentedTabs } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/toast";
import { demoInvitations } from "@/data/demo-data";

type Tab = "received" | "sent";

export default function InvitationsPage() {
  const { toast } = useToast();
  const [tab, setTab] = useState<Tab>("received");
  const [invitations, setInvitations] = useState<Invitation[]>(demoInvitations);

  const visible = useMemo(
    () => invitations.filter((inv) => inv.direction === tab),
    [invitations, tab],
  );

  const setStatus = (id: string, status: Invitation["status"]) =>
    setInvitations((list) =>
      list.map((inv) => (inv.id === id ? { ...inv, status } : inv)),
    );

  const handleAccept = (id: string) => {
    setStatus(id, "accepted");
    const inv = invitations.find((i) => i.id === id);
    toast({
      variant: "success",
      title: `You're going to ${inv?.eventTitle ?? "the event"}`,
      description: "Your RSVP is recorded locally for now.",
    });
  };

  const handleDecline = (id: string) => {
    setStatus(id, "declined");
    const inv = invitations.find((i) => i.id === id);
    toast({ title: `Declined ${inv?.eventTitle ?? "the invitation"}` });
  };

  const handleCancel = (id: string) => {
    const inv = invitations.find((i) => i.id === id);
    setInvitations((list) => list.filter((i) => i.id !== id));
    toast({ title: `Invitation to ${inv?.otherPartyName ?? "guest"} cancelled` });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight">Invitations</h1>
            <DemoDataBadge />
          </div>
          <p className="mt-1 text-muted-foreground">
            Track what you&apos;ve been invited to and who you&apos;ve asked.
          </p>
        </div>
        <SegmentedTabs
          tabs={[
            { value: "received", label: "Received" },
            { value: "sent", label: "Sent" },
          ]}
          value={tab}
          onChange={setTab}
        />
      </div>

      {visible.length === 0 ? (
        <EmptyState
          icon={tab === "received" ? MailOpen : Send}
          title={
            tab === "received" ? "No invitations yet" : "Nothing sent yet"
          }
          description={
            tab === "received"
              ? "When friends invite you to their events, they'll land here."
              : "Invitations you send from your events will appear here."
          }
        />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {visible.map((invitation) => (
            <InvitationCard
              key={invitation.id}
              invitation={invitation}
              onAccept={handleAccept}
              onDecline={handleDecline}
              onCancel={handleCancel}
            />
          ))}
        </div>
      )}
    </div>
  );
}
