import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { renderWithProviders } from "@/test/test-utils";
import InvitationsPage from "./page";

describe("InvitationsPage", () => {
  it("lists received invitations by default", () => {
    renderWithProviders(<InvitationsPage />);
    expect(screen.getByText("Board Game Night")).toBeInTheDocument();
    expect(screen.getByText("Charity 5K Walk")).toBeInTheDocument();
  });

  it("marks an invitation accepted after clicking Accept", async () => {
    renderWithProviders(<InvitationsPage />);

    // Two pending received invitations → Accept buttons; the third was
    // already accepted, so one "Accepted" badge exists beforehand.
    expect(screen.getAllByText("Accepted")).toHaveLength(1);
    const acceptButtons = screen.getAllByRole("button", { name: /accept/i });
    expect(acceptButtons).toHaveLength(2);

    await userEvent.click(acceptButtons[0]);

    expect(screen.getAllByText("Accepted")).toHaveLength(2);
    expect(
      await screen.findByText(/you're going to board game night/i),
    ).toBeInTheDocument();
  });

  it("shows the empty state when a tab has no pending content", async () => {
    renderWithProviders(<InvitationsPage />);
    await userEvent.click(screen.getByRole("tab", { name: /sent/i }));

    // Cancel both sent invitations to reveal the empty state
    for (const button of screen.getAllByRole("button", {
      name: /cancel invitation/i,
    })) {
      await userEvent.click(button);
    }
    expect(screen.getByText("Nothing sent yet")).toBeInTheDocument();
  });
});
