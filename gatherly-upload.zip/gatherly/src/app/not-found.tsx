import Link from "next/link";
import { Compass } from "lucide-react";
import { buttonClasses } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-4 text-center">
      <span className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-accent text-accent-foreground">
        <Compass className="h-7 w-7" />
      </span>
      <div>
        <p className="text-sm font-medium text-muted-foreground">404</p>
        <h2 className="mt-1 text-xl font-semibold">Page not found</h2>
        <p className="mt-1 max-w-md text-sm text-muted-foreground">
          The page you&apos;re looking for doesn&apos;t exist or may have been
          moved.
        </p>
      </div>
      <Link href="/" className={buttonClasses()}>
        Back to Home
      </Link>
    </div>
  );
}
