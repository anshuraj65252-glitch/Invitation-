import Link from "next/link";
import { CalendarPlus, Mail, Ticket, Users } from "lucide-react";
import { EventCard } from "@/components/features/event-card";
import { AvatarStack } from "@/components/ui/avatar";
import { DemoDataBadge } from "@/components/ui/badge";
import { buttonClasses } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { demoEvents, demoFriends, demoInvitations, demoProfile } from "@/data/demo-data";

export default function HomePage() {
  const pendingInvites = demoInvitations.filter(
    (inv) => inv.direction === "received" && inv.status === "pending",
  ).length;

  const stats = [
    {
      label: "Upcoming events",
      value: demoEvents.length,
      icon: Ticket,
      href: "/invitations",
    },
    {
      label: "Pending invitations",
      value: pendingInvites,
      icon: Mail,
      href: "/invitations",
    },
    {
      label: "Friends",
      value: demoFriends.filter((f) => f.status === "friend").length,
      icon: Users,
      href: "/friends",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Hero */}
      <section className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
              Good evening, {demoProfile.name.split(" ")[0]}
            </h1>
            <DemoDataBadge />
          </div>
          <p className="mt-1 text-muted-foreground">
            Here&apos;s what&apos;s happening with your circle.
          </p>
        </div>
        <Link href="/create-event" className={buttonClasses({ size: "lg" })}>
          <CalendarPlus className="h-5 w-5" />
          Create event
        </Link>
      </section>

      {/* Stats */}
      <section aria-label="Your activity at a glance">
        <div className="grid gap-4 sm:grid-cols-3">
          {stats.map(({ label, value, icon: Icon, href }) => (
            <Link key={label} href={href} className="group rounded-xl focus-visible:outline-ring">
              <Card className="flex items-center gap-4 p-5 transition-shadow group-hover:shadow-md">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                  <Icon className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-2xl font-bold tabular-nums">{value}</p>
                  <p className="text-sm text-muted-foreground">{label}</p>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Upcoming events */}
      <section aria-labelledby="upcoming-heading" className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 id="upcoming-heading" className="text-lg font-semibold">
            Upcoming events
          </h2>
          <Link
            href="/invitations"
            className="text-sm font-medium text-primary hover:underline"
          >
            View invitations
          </Link>
        </div>
        <div className="grid gap-4 lg:grid-cols-2">
          {demoEvents.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      </section>

      {/* Friends preview */}
      <section aria-labelledby="friends-heading">
        <Card className="flex flex-wrap items-center justify-between gap-4 p-5">
          <div className="flex items-center gap-4">
            <AvatarStack
              names={demoFriends.map((f) => f.name)}
              size="md"
              max={5}
            />
            <div>
              <h2 id="friends-heading" className="font-semibold">
                Your friends
              </h2>
              <p className="text-sm text-muted-foreground">
                {demoFriends.filter((f) => f.status === "friend").length} people
                in your circle
              </p>
            </div>
          </div>
          <Link href="/friends" className={buttonClasses({ variant: "outline" })}>
            See all friends
          </Link>
        </Card>
      </section>
    </div>
  );
}
