"use client";

import { useState } from "react";
import { Database, LogOut, MapPin, Pencil } from "lucide-react";
import { ThemePreferencePicker } from "@/components/layout/theme-toggle";
import { Avatar } from "@/components/ui/avatar";
import { Badge, DemoDataBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";
import { Input, Textarea } from "@/components/ui/input";
import { FieldHint, Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/toast";
import { isSupabaseConfigured } from "@/lib/supabase/client";
import { demoProfile } from "@/data/demo-data";
import type { Profile } from "@/types";

function EditProfileDialog({
  profile,
  open,
  onOpenChange,
  onSave,
}: {
  profile: Profile;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (next: Pick<Profile, "name" | "bio" | "location">) => void;
}) {
  const [name, setName] = useState(profile.name);
  const [bio, setBio] = useState(profile.bio);
  const [location, setLocation] = useState(profile.location);
  const [nameError, setNameError] = useState<string | null>(null);

  const handleOpenChange = (next: boolean) => {
    if (next) {
      // Re-sync fields with the latest saved profile each time it opens
      setName(profile.name);
      setBio(profile.bio);
      setLocation(profile.location);
      setNameError(null);
    }
    onOpenChange(next);
  };

  const save = () => {
    if (name.trim().length < 2) {
      setNameError("Your name needs at least 2 characters.");
      return;
    }
    onSave({
      name: name.trim(),
      bio: bio.trim(),
      location: location.trim(),
    });
    onOpenChange(false);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={handleOpenChange}
      title="Edit profile"
      description="Changes are stored locally until accounts arrive in a later phase."
      footer={
        <>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={save}>Save changes</Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="profile-name">Name</Label>
          <Input
            id="profile-name"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              setNameError(null);
            }}
            invalid={Boolean(nameError)}
            maxLength={60}
          />
          {nameError ? <FieldHint error>{nameError}</FieldHint> : null}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="profile-bio">Bio</Label>
          <Textarea
            id="profile-bio"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            maxLength={160}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="profile-location">Location</Label>
          <Input
            id="profile-location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            maxLength={60}
          />
        </div>
      </div>
    </Dialog>
  );
}

export default function ProfilePage() {
  const { toast } = useToast();
  const [profile, setProfile] = useState<Profile>(demoProfile);
  const [editOpen, setEditOpen] = useState(false);
  const [emailUpdates, setEmailUpdates] = useState(true);
  const supabaseReady = isSupabaseConfigured();

  const handleSave = (next: Pick<Profile, "name" | "bio" | "location">) => {
    setProfile((current) => ({ ...current, ...next }));
    toast({ variant: "success", title: "Profile updated" });
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="flex items-center gap-2">
        <h1 className="text-2xl font-bold tracking-tight">Profile</h1>
        <DemoDataBadge />
      </div>

      {/* Identity */}
      <Card>
        <CardContent className="flex flex-wrap items-center gap-4 p-6">
          <Avatar name={profile.name} size="lg" />
          <div className="min-w-0 flex-1">
            <h2 className="text-lg font-semibold">{profile.name}</h2>
            <p className="text-sm text-muted-foreground">{profile.handle}</p>
            {profile.bio ? (
              <p className="mt-1 text-sm">{profile.bio}</p>
            ) : null}
            {profile.location ? (
              <p className="mt-1.5 flex items-center gap-1 text-sm text-muted-foreground">
                <MapPin className="h-3.5 w-3.5" aria-hidden />
                {profile.location}
              </p>
            ) : null}
          </div>
          <Button variant="outline" onClick={() => setEditOpen(true)}>
            <Pencil className="h-4 w-4" />
            Edit
          </Button>
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Appearance</CardTitle>
          <CardDescription>
            Choose how Gatherly looks on this device.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ThemePreferencePicker />
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Notifications</CardTitle>
          <CardDescription>
            Preferences are stored locally in this phase.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-sm font-medium">Email updates</p>
              <p className="text-sm text-muted-foreground">
                Get a heads-up when invitations arrive.
              </p>
            </div>
            <Switch
              checked={emailUpdates}
              onCheckedChange={(checked) => {
                setEmailUpdates(checked);
                toast({
                  title: checked
                    ? "Email updates enabled"
                    : "Email updates muted",
                });
              }}
              label="Email updates"
            />
          </div>
        </CardContent>
      </Card>

      {/* Backend status */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Backend connection</CardTitle>
          <CardDescription>
            Supabase powers auth, events and invitations in later phases.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center gap-3">
          <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-muted text-muted-foreground">
            <Database className="h-5 w-5" />
          </span>
          <div className="flex-1">
            <p className="text-sm font-medium">Supabase</p>
            <p className="text-sm text-muted-foreground">
              {supabaseReady
                ? "Environment variables detected — ready to integrate."
                : "Not configured yet. Copy .env.example to .env.local to connect."}
            </p>
          </div>
          <Badge variant={supabaseReady ? "success" : "outline"}>
            {supabaseReady ? "Configured" : "Not configured"}
          </Badge>
        </CardContent>
      </Card>

      {/* Account */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Account</CardTitle>
          <CardDescription>
            There&apos;s no sign-in in this phase — everything you see is local
            preview data. Authentication ships with the backend.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button
            variant="destructive"
            disabled
            title="Sign-in isn't available in Phase 1"
          >
            <LogOut className="h-4 w-4" />
            Sign out
          </Button>
        </CardContent>
      </Card>

      <EditProfileDialog
        profile={profile}
        open={editOpen}
        onOpenChange={setEditOpen}
        onSave={handleSave}
      />
    </div>
  );
}
