"use client";

import { useMemo, useState } from "react";
import {
  Check,
  MessageCircle,
  Search,
  UserMinus,
  UserRoundPlus,
  UserSearch,
  X,
} from "lucide-react";
import type { Friend } from "@/types";
import { Avatar } from "@/components/ui/avatar";
import { DemoDataBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import { demoFriends } from "@/data/demo-data";

function FriendRow({
  friend,
  actions,
}: {
  friend: Friend;
  actions: React.ReactNode;
}) {
  return (
    <Card className="flex items-center justify-between gap-3 p-4">
      <div className="flex min-w-0 items-center gap-3">
        <Avatar name={friend.name} />
        <div className="min-w-0">
          <p className="truncate font-medium">{friend.name}</p>
          <p className="truncate text-sm text-muted-foreground">
            {friend.handle} · {friend.mutualFriends} mutual
          </p>
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-2">{actions}</div>
    </Card>
  );
}

export default function FriendsPage() {
  const { toast } = useToast();
  const [query, setQuery] = useState("");
  const [friends, setFriends] = useState<Friend[]>(
    demoFriends.filter((f) => f.status === "friend"),
  );
  const [incoming, setIncoming] = useState<Friend[]>(
    demoFriends.filter((f) => f.status === "incoming"),
  );
  const [outgoing, setOutgoing] = useState<Friend[]>(
    demoFriends.filter((f) => f.status === "outgoing"),
  );

  const normalizedQuery = query.trim().toLowerCase();
  const visibleFriends = useMemo(
    () =>
      normalizedQuery
        ? friends.filter(
            (f) =>
              f.name.toLowerCase().includes(normalizedQuery) ||
              f.handle.toLowerCase().includes(normalizedQuery),
          )
        : friends,
    [friends, normalizedQuery],
  );

  const acceptRequest = (friend: Friend) => {
    setIncoming((list) => list.filter((f) => f.id !== friend.id));
    setFriends((list) => [...list, { ...friend, status: "friend" }]);
    toast({
      variant: "success",
      title: `You're now friends with ${friend.name}`,
    });
  };

  const declineRequest = (friend: Friend) => {
    setIncoming((list) => list.filter((f) => f.id !== friend.id));
    toast({ title: `Declined ${friend.name}'s request` });
  };

  const cancelRequest = (friend: Friend) => {
    setOutgoing((list) => list.filter((f) => f.id !== friend.id));
    toast({ title: `Request to ${friend.name} cancelled` });
  };

  const removeFriend = (friend: Friend) => {
    setFriends((list) => list.filter((f) => f.id !== friend.id));
    toast({
      title: `Removed ${friend.name} from your friends`,
      description: "This is a local demo change only.",
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight">Friends</h1>
            <DemoDataBadge />
          </div>
          <p className="mt-1 text-muted-foreground">
            Manage your circle and friend requests.
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() =>
            toast({
              title: "Friend suggestions",
              description:
                "Suggestions will be powered by your contacts once the backend is connected.",
            })
          }
        >
          <UserRoundPlus className="h-4 w-4" />
          Find friends
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
          aria-hidden
        />
        <Input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search friends by name or handle…"
          aria-label="Search friends"
          className="pl-9"
        />
      </div>

      {/* Incoming requests */}
      {incoming.length > 0 && normalizedQuery === "" && (
        <section aria-labelledby="requests-heading" className="space-y-3">
          <h2 id="requests-heading" className="text-lg font-semibold">
            Friend requests
          </h2>
          <div className="grid gap-3">
            {incoming.map((friend) => (
              <FriendRow
                key={friend.id}
                friend={friend}
                actions={
                  <>
                    <Button size="sm" onClick={() => acceptRequest(friend)}>
                      <Check className="h-4 w-4" />
                      Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => declineRequest(friend)}
                    >
                      <X className="h-4 w-4" />
                      Decline
                    </Button>
                  </>
                }
              />
            ))}
          </div>
        </section>
      )}

      {/* Outgoing requests */}
      {outgoing.length > 0 && normalizedQuery === "" && (
        <section aria-labelledby="sent-heading" className="space-y-3">
          <h2 id="sent-heading" className="text-lg font-semibold">
            Sent requests
          </h2>
          <div className="grid gap-3">
            {outgoing.map((friend) => (
              <FriendRow
                key={friend.id}
                friend={friend}
                actions={
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => cancelRequest(friend)}
                  >
                    Cancel request
                  </Button>
                }
              />
            ))}
          </div>
        </section>
      )}

      {/* All friends */}
      <section aria-labelledby="all-friends-heading" className="space-y-3">
        <h2 id="all-friends-heading" className="text-lg font-semibold">
          All friends{" "}
          <span className="text-sm font-normal text-muted-foreground">
            ({visibleFriends.length})
          </span>
        </h2>

        {visibleFriends.length === 0 ? (
          <EmptyState
            icon={UserSearch}
            title={
              friends.length === 0
                ? "No friends yet"
                : `No results for “${query}”`
            }
            description={
              friends.length === 0
                ? "When you connect with people, they'll appear here."
                : "Try a different name or handle."
            }
            action={
              normalizedQuery ? (
                <Button variant="outline" onClick={() => setQuery("")}>
                  Clear search
                </Button>
              ) : undefined
            }
          />
        ) : (
          <div className="grid gap-3 lg:grid-cols-2">
            {visibleFriends.map((friend) => (
              <FriendRow
                key={friend.id}
                friend={friend}
                actions={
                  <>
                    <Button
                      size="icon"
                      variant="ghost"
                      disabled
                      title="Messaging arrives in Phase 2"
                      aria-label={`Message ${friend.name} (available in Phase 2)`}
                    >
                      <MessageCircle className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => removeFriend(friend)}
                      title={`Remove ${friend.name}`}
                      aria-label={`Remove ${friend.name}`}
                    >
                      <UserMinus className="h-4 w-4" />
                    </Button>
                  </>
                }
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
