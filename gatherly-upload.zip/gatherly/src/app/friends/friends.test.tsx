import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { renderWithProviders } from "@/test/test-utils";
import FriendsPage from "./page";

describe("FriendsPage", () => {
  it("filters the friend list from the search box", async () => {
    renderWithProviders(<FriendsPage />);
    await userEvent.type(screen.getByLabelText(/search friends/i), "ava");

    expect(screen.getByText("Ava Johnson")).toBeInTheDocument();
    expect(screen.queryByText("Rohan Mehta")).not.toBeInTheDocument();
  });

  it("shows an empty state with a clear action for unknown names", async () => {
    renderWithProviders(<FriendsPage />);
    await userEvent.type(screen.getByLabelText(/search friends/i), "zzz");

    expect(screen.getByText(/no results for/i)).toBeInTheDocument();
    await userEvent.click(
      screen.getByRole("button", { name: /clear search/i }),
    );
    expect(screen.getByText("Rohan Mehta")).toBeInTheDocument();
  });

  it("moves an accepted request into the friend list", async () => {
    renderWithProviders(<FriendsPage />);
    await userEvent.click(
      screen.getAllByRole("button", { name: /^accept$/i })[0],
    );
    expect(
      screen.getByText(/you're now friends with emma nakamura/i),
    ).toBeInTheDocument();
    // Friend requests section disappears once empty
    expect(screen.queryByText("Friend requests")).not.toBeInTheDocument();
  });
});
