"use client";

import { useState } from "react";
import { Globe, Lock, Users } from "lucide-react";
import type { EventPrivacy } from "@/types";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input, Textarea } from "@/components/ui/input";
import { FieldHint, Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/toast";
import { demoFriends } from "@/data/demo-data";

interface FormState {
  title: string;
  date: string;
  time: string;
  location: string;
  description: string;
  privacy: EventPrivacy;
}

const initialForm: FormState = {
  title: "",
  date: "",
  time: "",
  location: "",
  description: "",
  privacy: "friends",
};

const privacyOptions: {
  value: EventPrivacy;
  label: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { value: "public", label: "Public", description: "Anyone can see", icon: Globe },
  { value: "friends", label: "Friends", description: "Your circle only", icon: Users },
  { value: "private", label: "Private", description: "Invite only", icon: Lock },
];

function validate(form: FormState): Partial<Record<keyof FormState, string>> {
  const errors: Partial<Record<keyof FormState, string>> = {};
  if (form.title.trim().length < 3)
    errors.title = "Give your event a name (at least 3 characters).";
  if (!form.date) errors.date = "Pick a date.";
  if (!form.time) errors.time = "Pick a start time.";
  if (form.location.trim().length < 2)
    errors.location = "Add a location or meeting link.";
  return errors;
}

export default function CreateEventPage() {
  const { toast } = useToast();
  const [form, setForm] = useState<FormState>(initialForm);
  const [invitees, setInvitees] = useState<Set<string>>(new Set());
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [submitting, setSubmitting] = useState(false);

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: undefined }));
  };

  const toggleInvitee = (id: string) => {
    setInvitees((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors = validate(form);
    setErrors(nextErrors);
    if (Object.values(nextErrors).some(Boolean)) {
      toast({
        variant: "error",
        title: "Please fix the highlighted fields",
      });
      return;
    }

    setSubmitting(true);
    // No backend in Phase 1 — simulate the save so UX is reviewable end to end.
    window.setTimeout(() => {
      setSubmitting(false);
      toast({
        variant: "success",
        title: `“${form.title.trim()}” drafted`,
        description: `Saved locally with ${invitees.size} invitee${invitees.size === 1 ? "" : "s"}. It will sync once Supabase is connected.`,
      });
      setForm(initialForm);
      setInvitees(new Set());
    }, 600);
  };

  const inviteableFriends = demoFriends.filter((f) => f.status === "friend");

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Create event</h1>
        <p className="mt-1 text-muted-foreground">
          Plan something and invite your people. Details are stored locally in
          this phase.
        </p>
      </div>

      <form onSubmit={handleSubmit} noValidate className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Event details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-1.5">
              <Label htmlFor="event-title">Event name</Label>
              <Input
                id="event-title"
                value={form.title}
                onChange={(e) => update("title", e.target.value)}
                placeholder="e.g. Rooftop Potluck Dinner"
                invalid={Boolean(errors.title)}
                maxLength={80}
              />
              {errors.title ? <FieldHint error>{errors.title}</FieldHint> : null}
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="event-date">Date</Label>
                <Input
                  id="event-date"
                  type="date"
                  value={form.date}
                  onChange={(e) => update("date", e.target.value)}
                  invalid={Boolean(errors.date)}
                />
                {errors.date ? <FieldHint error>{errors.date}</FieldHint> : null}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="event-time">Start time</Label>
                <Input
                  id="event-time"
                  type="time"
                  value={form.time}
                  onChange={(e) => update("time", e.target.value)}
                  invalid={Boolean(errors.time)}
                />
                {errors.time ? <FieldHint error>{errors.time}</FieldHint> : null}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="event-location">Location</Label>
              <Input
                id="event-location"
                value={form.location}
                onChange={(e) => update("location", e.target.value)}
                placeholder="Address, venue or video link"
                invalid={Boolean(errors.location)}
                maxLength={120}
              />
              {errors.location ? (
                <FieldHint error>{errors.location}</FieldHint>
              ) : null}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="event-description">
                Description{" "}
                <span className="font-normal text-muted-foreground">
                  (optional)
                </span>
              </Label>
              <Textarea
                id="event-description"
                value={form.description}
                onChange={(e) => update("description", e.target.value)}
                placeholder="What should guests know? Dress code, what to bring…"
                maxLength={500}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Who can see this event?</CardTitle>
          </CardHeader>
          <CardContent>
            <div
              role="radiogroup"
              aria-label="Event privacy"
              className="grid gap-2 sm:grid-cols-3"
            >
              {privacyOptions.map(({ value, label, description, icon: Icon }) => {
                const active = form.privacy === value;
                return (
                  <button
                    key={value}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    onClick={() => update("privacy", value)}
                    className={cn(
                      "flex flex-col items-start gap-1 rounded-xl border p-4 text-left transition-colors",
                      active
                        ? "border-primary bg-accent"
                        : "border-border hover:bg-muted",
                    )}
                  >
                    <span className="flex items-center gap-2 font-medium">
                      <Icon className="h-4 w-4" />
                      {label}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {description}
                    </span>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              Invite friends{" "}
              <span className="font-normal text-muted-foreground">
                ({invitees.size} selected · demo list)
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            {inviteableFriends.map((friend) => {
              const checked = invitees.has(friend.id);
              return (
                <label
                  key={friend.id}
                  className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-2 transition-colors hover:bg-muted"
                >
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => toggleInvitee(friend.id)}
                    className="h-4 w-4 shrink-0 accent-[var(--primary)]"
                    aria-label={`Invite ${friend.name}`}
                  />
                  <Avatar name={friend.name} size="sm" />
                  <span className="min-w-0 flex-1 truncate text-sm font-medium">
                    {friend.name}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {friend.handle}
                  </span>
                </label>
              );
            })}
          </CardContent>
        </Card>

        <div className="flex gap-2 pb-2">
          <Button type="submit" size="lg" className="flex-1" loading={submitting}>
            {submitting ? "Saving draft…" : "Create event"}
          </Button>
          <Button
            type="button"
            size="lg"
            variant="outline"
            disabled={submitting}
            onClick={() => {
              setForm(initialForm);
              setInvitees(new Set());
              setErrors({});
              toast({ title: "Form cleared" });
            }}
          >
            Clear
          </Button>
        </div>
      </form>
    </div>
  );
}
