import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { renderWithProviders } from "@/test/test-utils";
import CreateEventPage from "./page";

describe("CreateEventPage", () => {
  it("shows field-level errors when submitting an empty form", async () => {
    renderWithProviders(<CreateEventPage />);
    await userEvent.click(
      screen.getByRole("button", { name: /create event/i }),
    );

    expect(screen.getByText(/give your event a name/i)).toBeInTheDocument();
    expect(screen.getByText(/pick a date/i)).toBeInTheDocument();
    expect(screen.getByText(/pick a start time/i)).toBeInTheDocument();
    expect(screen.getByText(/add a location/i)).toBeInTheDocument();
  });

  it("clears the form with the Clear button", async () => {
    renderWithProviders(<CreateEventPage />);
    const title = screen.getByLabelText(/event name/i);
    await userEvent.type(title, "Picnic");
    await userEvent.click(screen.getByRole("button", { name: /^clear$/i }));

    expect(title).toHaveValue("");
  });

  it("marks required fields invalid for assistive tech after a failed submit", async () => {
    renderWithProviders(<CreateEventPage />);
    await userEvent.click(
      screen.getByRole("button", { name: /create event/i }),
    );
    expect(screen.getByLabelText(/event name/i)).toHaveAttribute(
      "aria-invalid",
      "true",
    );
  });
});
